chart.py - saves chart data in a mongodb collection and returns a pandas dataframe with basic indicators

Requires:
```
pandas
numpy
pymongo
```
